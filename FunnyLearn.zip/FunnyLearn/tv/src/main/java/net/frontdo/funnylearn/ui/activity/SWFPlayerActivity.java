package net.frontdo.funnylearn.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.WebSettings;
import android.webkit.WebView;

import net.frontdo.funnylearn.R;
import net.frontdo.funnylearn.base.BaseHoldBackActivity;
import net.frontdo.funnylearn.common.StringUtil;
import net.frontdo.funnylearn.logger.FrontdoLogger;

import java.util.List;

import butterknife.Bind;

import static net.frontdo.funnylearn.app.AppConstants.IKEY_VIDEO_URL;

public class SWFPlayerActivity extends BaseHoldBackActivity {
    private static final String TAG = SWFPlayerActivity.class.getSimpleName();

    @Bind(R.id.webview)
    WebView webview;

    private String videoUrl;

    @Override
    protected int onBindLayout() {
        return R.layout.activity_swf_player;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        if (intent.hasExtra(IKEY_VIDEO_URL)) {
            videoUrl = intent.getStringExtra(IKEY_VIDEO_URL);
        }

        if (StringUtil.checkEmpty(videoUrl)) {
            FrontdoLogger.getLogger().e(TAG, "[ " + TAG + " - onCreate] videoUrl is empty!");
            finish();
            return;
        }

        initView();
    }

    private void initView() {
//        showProgressDlg(null, true);
        WebSettings setting = webview.getSettings();
        setting.setPluginState(WebSettings.PluginState.ON);
        setting.setJavaScriptEnabled(true);

        webview.loadUrl(videoUrl);
//        if (check()) {
//            webview.loadUrl(videoUrl);
//        } else {
//            install();
//        }
    }

    private boolean check() {
        PackageManager pm = getPackageManager();
        List<PackageInfo> infoList = pm.getInstalledPackages(PackageManager.GET_SERVICES);
        for (PackageInfo info : infoList) {
            if ("com.adobe.flashplayer".equals(info.packageName)) {
                return true;
            }
        }
        return false;
    }

    private final Handler handler = new Handler();
    private class AndroidBridge {
        public void goMarket() {
            handler.post(new Runnable() {
                public void run() {
                    Intent installIntent = new Intent("android.intent.action.VIEW");
                    installIntent.setData(Uri.parse("market://details?id=com.adobe.flashplayer"));
                    startActivity(installIntent);
                }
            });
        }
    }

    private void install() {
        webview.addJavascriptInterface(new AndroidBridge(), "android");
        webview.loadUrl("file:///android_asset/go_market.html");
    }

    public static void boot(Context context, String videoUrl) {
        Intent intent = new Intent(context, SWFPlayerActivity.class);
        intent.putExtra(IKEY_VIDEO_URL, videoUrl);
        context.startActivity(intent);
    }
}
