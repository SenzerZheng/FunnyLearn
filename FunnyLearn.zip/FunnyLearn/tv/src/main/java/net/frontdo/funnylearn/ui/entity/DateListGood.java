package net.frontdo.funnylearn.ui.entity;

import java.io.Serializable;

import lombok.Data;

/**
 * ProjectName: DateListGood
 * Description: 商品：APP 或 视频
 * <p>
 * 现在只是为了测试数据，没有实际意义，等待后台数据更新
 * <p>
 * author: JeyZheng
 * version: 1.0
 * created at: 11/15/2016 21:21
 */
@Deprecated
@Data
public class DateListGood implements Serializable {
    private String date;
}
