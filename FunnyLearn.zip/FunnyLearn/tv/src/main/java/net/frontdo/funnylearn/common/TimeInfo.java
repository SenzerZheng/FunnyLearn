package net.frontdo.funnylearn.common;

/**
 * @author: yanglingyun
 * Date: 2016-01-15
 * Time: 18:10
 * Des:
 */
public class TimeInfo {

    private long startTime;
    private long endTime;

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }
}
